<?php

include("conexion.php");

if (isset($_POST['email']) && strlen($_POST['email'] >= 1)) {

	$email = $_POST['email'];

	$consulta = "INSERT INTO datos(email) VALUES ('$email')";
	
	if ($conex->query($consulta) === true) {
		echo "Email obtenido con exito";
	}else{
		die("Error datos no registrados: ".$conex->error);
	}
}else{
	echo "Ingrese su email en el campo de texto";
}
?>